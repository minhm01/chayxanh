
<?php $__env->startSection('admin_content'); ?>
<?php
$msg=Session::get('message');
if($msg)	{
    echo $msg;
    Session::put('message',null);
}
?>
<div class="table-agile-info">
  <div class="panel panel-danger">
    <div class="panel-heading">
      yêu cầu chưa xử lý
    </div>
    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <th style="width:20px;">
              <label class="i-checks m-b-none">
                <input type="checkbox"><i></i>
              </label>
            </th>
            <th>Chi nhánh</th>
            <th>Ngày</th>
            <th>Ca</th>
            <th>Vị trí</th>
            <th>Ghi chú</th>
            <th>Ngày gửi</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $dispatch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(!($dp->result)) {?>
          <tr>
            <td>
              <label class="i-checks m-b-none">
                <input type="checkbox"><i></i>
              </label>
            </td>
            <td title="<?php echo e($dp->address); ?>"><?php echo e($dp->br_id); ?></td>
            <td><?php echo e($dp->date); ?></td>
            <td><?php echo e($dp->shift_id); ?></td>
            <td><?php $__currentLoopData = $pos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if(str_contains($dp->position,$ps->eng)) echo $ps->vie.'<br>' ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
            <td><?php echo e($dp->note); ?></td>
            <td><?php echo e(date_format(new Datetime($dp->created_at),'Y-m-d')); ?></td>
            <td>
              <a class="btn btn-success" href="<?php echo e(URL::to('/send-dispatch/'.$dp->dp_id)); ?>">Điều phối</a>
            </td>
          </tr>
          <?php } ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      yêu cầu đã xử lý
    </div>
    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <th style="width:20px;">
              <label class="i-checks m-b-none">
                <input type="checkbox"><i></i>
              </label>
            </th>
            <th>Chi nhánh</th>
            <th>Ngày</th>
            <th>Ca</th>
            <th>Số nhân viên</th>
            <th>Ghi chú</th>
            <th>Ngày gửi</th>
            <th>Ngày xử lý</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $dispatch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($dp->result) {?>
          <tr>
            <td>
              <label class="i-checks m-b-none">
                <input type="checkbox"><i></i>
              </label>
            </td>
            <td title="<?php echo e($dp->address); ?>"><?php echo e($dp->br_id); ?></td>
            <td><?php echo e($dp->date); ?></td>
            <td><?php echo e($dp->shift_id); ?></td>
            <td><?php echo e($dp->emp); ?></td>
            <td><?php echo e($dp->note); ?></td>
            <td><?php echo e(date_format(new Datetime($dp->created_at),'Y-m-d')); ?></td>
            <td><?php echo e(date_format(new Datetime($dp->updated_at),'Y-m-d')); ?></td>
          </tr>
          <?php } ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Study\xampp\htdocs\chayxanh\resources\views/admin/dispatch/all_dispatch.blade.php ENDPATH**/ ?>