
<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Thêm nhân viên
            </header>
            <div class="panel-body">
                <?php
                $msg=Session::get('message');
                $brch=Session::get('br');
                if($msg)	{
                    echo $msg;
                    Session::put('message',null);
                }
                ?>
                <div class="position-center">
                    <form role="form" action="<?php echo e(URL::to('/save-employee')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="name">Tên nhân viên </label>
                        <input type="text" class="form-control" name="name" placeholder="" required>
                    </div>
                    <label for="br">Chi nhánh </label>
                    <select class="form-control input-lg m-bot15" name="br" <?php if($brch) echo 'disabled' ?>>
                        <?php $__currentLoopData = $br_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $br): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
                        <option <?php if($brch==$br->br_id) echo 'selected' ?> value=<?php echo e($br->br_id); ?>><?php echo e($br->address); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <label for="gender">Giới tính </label>
                    <select class="form-control input-lg m-bot15" name="gender">
                        <option value="Nam">Nam</option>
                        <option value="Nữ">Nữ</option>                        
                    </select>
                    <div class="form-group">
                        <label for="phone">Số điện thoại </label>
                        <input type="text" class="form-control" name="phone" placeholder="" required>
                    </div>
                    <div class="form-group">
                        <label for="pid">Số CCCD </label>
                        <input type="text" class="form-control" name="pid" placeholder="" required>
                    </div>                    
                    <button type="submit" name="add_employee" class="btn btn-info">Thêm</button>
                </form>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Study\xampp\htdocs\chayxanh\resources\views/admin/employee/add_employee.blade.php ENDPATH**/ ?>