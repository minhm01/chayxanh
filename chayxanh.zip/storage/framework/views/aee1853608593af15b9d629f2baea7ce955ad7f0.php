
<?php $__env->startSection('admin_content'); ?>
<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      Danh sách nhân viên
    </div>
    <?php
    $msg=Session::get('message');
    if($msg)	{
        echo $msg;
        Session::put('message',null);
    }
    $admin=Session::get('ad_id');
    $manager=Session::get('br');
    ?>
    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <th style="width:20px;">
              <label class="i-checks m-b-none">
                <input type="checkbox"><i></i>
              </label>
            </th>
            <th style="width:30px;"></th>
            <th>Tên</th>
            <th>Giới tính</th>
            <th>Chi nhánh</th>
            <th>Ngày vào làm</th>
            <th>SĐT</th>
            <th>Số CCCD</th>
            <th>Chức vụ</th>
            <th style="width:30px;"></th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $all_employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($admin||$emp->br_id==$manager) { ?>
          <tr>
            <td><label class="i-checks m-b-none"><input type="checkbox" name="post[]"><i></i></label></td>
            <td><?php echo e($emp->emp_id); ?></td>
            <td><?php echo e($emp->emp_name); ?></td>
            <td><?php echo e($emp->gender); ?></td>
            <td><div title="<?php echo e($emp->address); ?>"><?php echo e($emp->br_id); ?></div></td>
            <td><?php echo e($emp->emp_dob); ?></td>
            <td><?php echo e($emp->emp_phone); ?></td>
            <td><?php echo e($emp->emp_pid); ?></td>            
            <td><div class="btn btn-light">
              <?php if($emp->role=="employee")
            {
              ?>Nhân viên</div><?php
            }
            else {
              ?>Quản lý</div><?php
            }
            ?><div><a href="<?php echo e(URL::to('/add-work/'.$emp->emp_id)); ?>" class="btn btn-success">Xếp lịch</a></div>
            </td>

            <td>
                <a href="<?php echo e(URL::to('/edit-employee/'.$emp->emp_id)); ?>" class="btn btn-info">Sửa</a>
                <a onclick="return confirm('Xác nhận xóa nhân viên?')" href="<?php echo e(URL::to('/del-employee/'.$emp->emp_id)); ?>" class="btn btn-danger">Xóa</a>
            </td>
          </tr>
          <?php } ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Study\xampp\htdocs\chayxanh\resources\views/admin/employee/all_employee.blade.php ENDPATH**/ ?>