
<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Cập nhật chi nhánh
            </header>
            <div class="panel-body">
                <?php
                $brch=Session::get('br');
                $msg=Session::get('message');
                $admin=Session::get('ad_id');
                if($msg)	{
                    echo $msg;
                    Session::put('message',null);
                }                
                ?>
                <?php $__currentLoopData = $edit_employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="position-center">
                    <form role="form" action="<?php echo e(URL::to('/upd-employee/'.$edit->emp_id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="name">Tên nhân viên </label>
                            <input type="text" class="form-control" value="<?php echo e($edit->emp_name); ?>" name="name" placeholder="" required>
                        </div>
                        <label for="br">Chi nhánh </label>
                        <select class="form-control input-lg m-bot15" name="br" <?php if($brch) echo 'disabled' ?>>
                            <?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $br): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                        
                            <option value=<?php echo e($br->br_id); ?> <?php if($br->br_id==$edit->br_id) echo "selected"; ?>><?php echo e($br->address); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label for="gender">Giới tính </label>
                        <select class="form-control input-lg m-bot15" name="gender">
                            <option value="Nam" <?php if($edit->gender=="Nam") echo "selected"; ?>>Nam</option>
                            <option value="Nữ" <?php if($edit->gender=="Nữ") echo "selected"; ?>>Nữ</option>                        
                        </select>
                        <div class="form-group">
                            <label for="phone">Số điện thoại </label>
                            <input type="text" class="form-control" value="<?php echo e($edit->emp_phone); ?>" name="phone" placeholder="" required>
                        </div>
                        <div class="form-group">
                            <label for="pid">Số CCCD </label>
                            <input type="text" class="form-control" value="<?php echo e($edit->emp_pid); ?>" name="pid" placeholder="" required>
                        </div>                               
                    <button type="submit" name="add_branch" class="btn btn-info">Sửa</button>
                    <?php                    
                    if($admin){
                        if($edit->role=="employee"){ ?>
                        <a href="<?php echo e(URL::to('/promote/'.$edit->emp_id)); ?>"class="btn btn-success">Thăng chức</a>
                    <?php }
                    else{ ?>
                        <a href="<?php echo e(URL::to('/demote/'.$edit->emp_id)); ?>" class="btn btn-danger">Cách chức</a>'
                    <?php }} ?>
                </form>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Study\xampp\htdocs\chayxanh\resources\views/admin/employee/edit_employee.blade.php ENDPATH**/ ?>