
<?php $__env->startSection('admin_content'); ?>
<?php
    
    $dat = new DateTime(); $date=($dat->format( 'N' )+1);
    $msg=Session::get('message');
    if($msg)	{
        echo $msg;
        Session::put('message',null);
    }
    $admin=Session::get('ad_id');
    $manager=Session::get('br');
    $head=1;
    ?>
<?php $__currentLoopData = $branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($admin||$branch->br_id==$manager) { ?>
<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading" style="text-align: left">
      Chi nhánh <?php echo e($branch->br_id); ?>. <?php echo e($branch->address); ?>

    </div>    

      <ul class="nav nav-pills nav-justified">
        <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li <?php if($wk->id==$date) echo 'class="active"'; ?>><a data-toggle="pill" href="#day<?php echo e($wk->id); ?>br<?php echo e($branch->br_id); ?>"><?php echo e($wk->day2); ?></a></li>      
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>

    <div class="tab-content">
      <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div id="day<?php echo e($wk->id); ?>br<?php echo e($branch->br_id); ?>" class="tab-pane fade <?php if($wk->id==$date) { ?> in active <?php } ?> ">
        <ul class="nav nav-pills nav-stacked">
          <div class="table-responsive">
            <table class="table table-striped b-t b-light">
              <thead>
                <tr>
                  <th style="width:25%;">Ca</th>
                  <th>Vị trí</th>
                  <th>Nhân viên</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <?php if($head==1) { $head=0; ?>
                  <td rowspan="4" style="font-size: 40px"><?php echo e($sh->shift_id); ?></br><?php echo e(substr($sh->start,0,5)); ?>-<?php echo e(substr($sh->end,0,5)); ?>

                  </td> <?php } ?>
                  <td><span class="text-ellipsis"><?php echo e($pos->vie); ?></span></td>
                  <td><span class="text-ellipsis">
                    <?php $__currentLoopData = $work; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wrk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                    <?php if($wrk->br_id==$branch->br_id&&$wrk->shift_id==$sh->shift_id&&$wrk->day==$wk->id&&$wrk->position==$pos->eng) { ?>
                    <div><?php echo e($wrk->emp_name); ?></div>
                    <?php }?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                  </span></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $head=1; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>          
        </ul>
      </div>      
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<?php } ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Study\xampp\htdocs\chayxanh\resources\views/admin/work/all_work.blade.php ENDPATH**/ ?>