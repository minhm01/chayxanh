
<?php $__env->startSection('admin_content'); ?>
<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading">
      Danh sách chấm công
    </div>
    <?php
    $msg=Session::get('message');
    if($msg)	{
        echo $msg;
        Session::put('message',null);
    }
    $admin=Session::get('ad_id');
    $manager=Session::get('br');
    ?>
    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>
            <th style="width:20px;">
              <label class="i-checks m-b-none">
                <input type="checkbox"><i></i>
              </label>
            </th>
            <th>Mã nhân viên</th>
            <th>Chi nhánh</th>
            <th>Ngày</th>
            <th>Ca</th>
            <th>Giờ vào</th>
            <th>Giờ ra</th>
            <th>Thời gian</th>
            <th>Kết quả</th>            
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $attend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $att): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($admin||$att->br_id==$manager) { ?>
          <tr>
            <td><label class="i-checks m-b-none"><input type="checkbox" name="post[]"><i></i></label></td>
            <th><?php echo e($att->emp_id); ?></th>
            <th><?php echo e($att->br_id); ?></th>
            <th><?php echo e($att->date); ?></th>
            <th><?php echo e($att->shift_id); ?></th>
            <th><?php echo e($att->checkin); ?></th>
            <th><?php echo e($att->checkout); ?></th>
            <th><?php echo e($att->duration); ?></th>
            <th><div class="dropdown">
              <button class="btn btn-<?php echo e($att->button); ?> dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php echo e($att->vie); ?>

              </button>
              <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($res->eng!=$att->result) { ?><a class="dropdown-item btn btn-<?php echo e($res->button); ?>" href="#"><?php echo e($res->vie); ?></a><?php } ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
            </th>
          </tr>
        <?php } ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Study\xampp\htdocs\chayxanh\resources\views/admin/all_attend.blade.php ENDPATH**/ ?>