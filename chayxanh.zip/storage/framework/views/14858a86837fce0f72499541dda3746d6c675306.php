
<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Phân công công việc
            </header>
            <div class="panel-body">
                <?php
                $brch=Session::get('br');
                $msg=Session::get('message');
                if($msg)	{
                    echo $msg;
                    Session::put('message',null);
                }
                ?>
                <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="position-center">
                    <form role="form" action="<?php echo e(URL::to('/save-work/'.$emp->emp_id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="name">Tên nhân viên </label>
                            <input type="text" class="form-control" value="<?php echo e($emp->emp_name); ?>" name="name" placeholder="" disabled>
                        </div>
                        <div class="form-group">
                            <label for="name">Chi nhánh </label>
                            <input type="text" class="form-control" value="<?php echo e($emp->br_id); ?>.<?php echo e($emp->address); ?>" name="name" placeholder="" disabled>
                        </div>
                        <label for="gender">Ca làm </label>
                        <select class="form-control input-lg m-bot15" name="shift" required>                            
                            <?php $__currentLoopData = $shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value=<?php echo e($s->shift_id); ?>>Ca <?php echo e($s->shift_id); ?>. Từ <?php echo e(substr($s->start,0,5)); ?> giờ đến <?php echo e(substr($s->end,0,5)); ?> giờ</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="checkbox">
                            <?php $__currentLoopData = $weekday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label>
                                <input type="checkbox" name="day[]" value=<?php echo e($day->id); ?>><?php echo e($day->day2); ?>

                            </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="form-group">
                            <label for="position">Vị trí </label>
                            <div class="radio">
                                <label>
                                    <input type="radio" name="position" value="cook" checked>
                                    Bếp
                                </label>
                            </div>
                            <div class="radio">
                                <label>
                                    <input type="radio" name="position" value="chef">
                                    Bếp trưởng
                                </label>
                            </div>                            
                            <div class="radio">
                                <label>
                                    <input type="radio" name="position" value="waiter" >
                                    Phục vụ
                                </label>
                            </div>
                        </div>
                        <button type="submit" name="editwork" class="btn btn-info">Thêm</button>                    
                    </form>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Study\xampp\htdocs\chayxanh\resources\views/admin/work/edit_work.blade.php ENDPATH**/ ?>