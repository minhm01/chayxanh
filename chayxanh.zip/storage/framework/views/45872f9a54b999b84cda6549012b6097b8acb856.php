
<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Thêm chi nhánh
            </header>
            <div class="panel-body">
                <?php
                $msg=Session::get('message');
                if($msg)	{
                    echo $msg;
                    Session::put('message',null);
                }
                ?>
                <div class="position-center">
                    <form role="form" action="<?php echo e(URL::to('/save-branch')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="address">Địa chỉ </label>
                        <input type="text" class="form-control" name="address" placeholder="Địa chỉ chi nhánh" required>
                    </div>                    
                    <button type="submit" name="add_branch" class="btn btn-info">Thêm</button>
                </form>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Study\xampp\htdocs\chayxanh\resources\views/admin/branch/add_branch.blade.php ENDPATH**/ ?>