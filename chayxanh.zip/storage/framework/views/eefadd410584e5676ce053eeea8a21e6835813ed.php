
<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-3">
        <section class="panel">
            <table class="table table-striped b-t b-light">                
                <tbody>
                  <tr>
                    <th>Chi nhánh</th>
                    <td><?php echo e($dispatch->br_id); ?></td>
                  </tr>
                  <tr>
                    <th>Ngày</th>
                    <td><?php echo e($dispatch->date); ?></td>
                  </tr>
                  <tr>
                    <th>Ca</th>
                    <td><?php echo e($dispatch->shift_id); ?></td>
                  </tr>
                  <tr>
                    <th>Vị trí</th>
                    <td><?php $__currentLoopData = $pos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if(str_contains($dispatch->position,$ps->eng)) echo $ps->vie.'<br>' ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                  </tr>
                  <tr>
                    <th>Ghi chú</th>
                    <td><?php echo e($dispatch->note); ?></td>
                  </tr>
                </tbody>
              </table>
        </section>
    </div>
    <div class="col-lg-9">
        <form role="form" action="<?php echo e(URL::to('/upd-dispatch/')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="dp" value=<?php echo e($dispatch->dp_id); ?>>
            <section class="panel">
                <header class="panel-heading">
                    danh sách nhân viên
                </header>
                <table class="table table-striped b-t b-light">
                    <thead>
                        <tr>
                            <th></th>
                            <th>Tên</th>
                            <th>Chi nhánh</th>
                            <th>Chức vụ</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $emp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($emp->emp_id); ?></td>
                            <td><?php echo e($emp->emp_name); ?></td>
                            <td><?php echo e($emp->br_id); ?></td>
                            <td><?php if($emp->role=="employee") echo 'Nhân viên'; else echo 'Quản lý'; ?></td>
                            <td><input type="checkbox" name="emp[]" value=<?php echo e($emp->emp_id); ?>></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="panel-body">
                    <button type="submit" name="add_branch" class="btn btn-info">Xác nhận</button>
                </div>
            </section>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Study\xampp\htdocs\chayxanh\resources\views/admin/dispatch/edit_dispatch.blade.php ENDPATH**/ ?>