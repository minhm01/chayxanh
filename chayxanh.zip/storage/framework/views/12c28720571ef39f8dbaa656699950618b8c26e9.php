
<?php $__env->startSection('emp_content'); ?>
<?php    
    $dat = new DateTime(); 
    $date=($dat->format( 'N' )+1);
    $now=($dat->format('H:i'));    
    $msg=Session::get('message');
    if($msg)	{
        echo $msg;
        Session::put('message',null);
    }
    ?>
<div class="table-agile-info">
  <div class="panel panel-default">
    <div class="panel-heading" style="text-align: left">
      <p>Nhân viên: <?php echo e(Session::get('employee')); ?></p>
    </div>
    <div class="panel-heading" style="text-align: left">
      <p>Chi nhánh <?php echo e($branch->br_id); ?>: <?php echo e($branch->address); ?></p>
    </div>      
    <div class="table-responsive">
      <table class="table table-striped b-t b-light">
        <thead>
          <tr>                  
            <th>Ngày</th>                  
            <?php $__currentLoopData = $weekday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th <?php if($wk->id==$date) echo 'class="btn-primary"'?>><?php echo e($wk->day2); ?></th>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>                
        </thead>
        <tbody>                
          <?php $__currentLoopData = $shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td <?php if($sh->start<=$now&&$now<=$sh->end) echo 'class="btn-primary"'?>><h3>Ca <?php echo e($sh->shift_id); ?></h2><br><?php echo e(substr($sh->start,0,5)); ?>-<?php echo e(substr($sh->end,0,5)); ?></td>
            <?php $__currentLoopData = $weekday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td <?php if($sh->start<=$now&&$now<=$sh->end&&$wk->id==$date ) echo 'class="btn-primary"'; ?>>              
              <?php $__currentLoopData = $work; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wrk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
              <?php 
               if($wrk->shift_id==$sh->shift_id&&$wrk->day==$wk->id) {                  
                switch($wrk->position) {
                  case 'manager': echo '<h3>Quản lý</h3>'; break;
                  case 'chef': echo '<h3>Bếp trưởng</h3>'; break;
                  case 'cook': echo '<h3>Bếp</h3>'; break;
                  case 'waiter': echo '<h3>Phục vụ</h3>';
                };              
              } ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
            </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('emp_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Study\xampp\htdocs\chayxanh\resources\views/emp/all_work.blade.php ENDPATH**/ ?>