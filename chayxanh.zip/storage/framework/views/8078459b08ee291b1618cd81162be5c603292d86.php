
<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Cập nhật chi nhánh
            </header>
            <div class="panel-body">
                <?php
                $msg=Session::get('message');
                if($msg)	{
                    echo $msg;
                    Session::put('message',null);
                }
                ?>
                <?php $__currentLoopData = $edit_branch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="position-center">
                    <form role="form" action="<?php echo e(URL::to('/upd-branch/'.$edit->br_id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="address">Địa chỉ </label>
                        <input type="text" value="<?php echo e($edit->address); ?>" class="form-control" name="address" placeholder="Địa chỉ chi nhánh">
                    </div>                    
                    <button type="submit" name="add_branch" class="btn btn-info">Sửa</button>
                </form>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Study\xampp\htdocs\chayxanh\resources\views/admin/edit_branch.blade.php ENDPATH**/ ?>