
<?php $__env->startSection('emp_content'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('emp_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Study\xampp\htdocs\chayxanh\resources\views/emp/dashboard.blade.php ENDPATH**/ ?>